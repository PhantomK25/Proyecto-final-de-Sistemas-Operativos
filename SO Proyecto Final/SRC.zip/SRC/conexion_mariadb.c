#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    MYSQL *conn; // Conexión
    MYSQL_RES *res; // Resultado
    MYSQL_ROW row; // Fila

    const char *server = "localhost"; // Servidor
    const char *user = "root"; // Usuario
    const char *password = "tu_password"; // Contraseña del usuario root
    const char *database = "sistema_educativo"; // Base de datos

    // Inicializar la conexión
    conn = mysql_init(NULL);

    if (conn == NULL) {
        fprintf(stderr, "mysql_init() falló\n");
        exit(1);
    }

    // Conectar a MariaDB
    if (mysql_real_connect(conn, server, user, password, database, 0, NULL, 0) == NULL) {
        fprintf(stderr, "Error de conexión: %s\n", mysql_error(conn));
        mysql_close(conn);
        exit(1);
    }

    printf("Conexión exitosa a la base de datos\n");

    // Realizar una consulta
    if (mysql_query(conn, "SELECT * FROM estudiantes")) {
        fprintf(stderr, "Error en consulta: %s\n", mysql_error(conn));
        mysql_close(conn);
        exit(1);
    }

    res = mysql_store_result(conn);
    if (res == NULL) {
        fprintf(stderr, "Error al obtener resultados: %s\n", mysql_error(conn));
        mysql_close(conn);
        exit(1);
    }

    // Imprimir los resultados
    printf("ID | Nombre | Primer Apellido | Segundo Apellido | Edad | Matrícula | Grado | Materias\n");
    while ((row = mysql_fetch_row(res)) != NULL) {
        printf("%s | %s | %s | %s | %s | %s | %s | %s\n",
               row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7]);
    }

    // Liberar memoria y cerrar conexión
    mysql_free_result(res);
    mysql_close(conn);

    return 0;
}
