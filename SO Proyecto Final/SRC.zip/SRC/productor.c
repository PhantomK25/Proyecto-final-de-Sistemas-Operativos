#include <stdio.h>
#include <string.h>
#include <mosquitto.h>

int main() {
    struct mosquitto *mosq;
    int ret;
    char mensaje[512]; // Aseguramos un tamaño suficiente para incluir todos los datos

    // Datos del estudiante
    char nombre[50] = "Yarely";
    char primer_apellido[50] = "Shmith";
    char segundo_apellido[50] = "Miranda";
    int edad = 20;
    int matricula = 226020006;
    int grado = 5;
    char materias[100] = "Matemáticas, Física";

    // Crear el mensaje para enviar
    snprintf(mensaje, sizeof(mensaje), 
             "Nuevo estudiante, Nombre: %s, Primer Apellido: %s, Segundo Apellido: %s, Edad: %d, Matrícula: %d, Grado: %d, Materias: %s", 
             nombre, primer_apellido, segundo_apellido, edad, matricula, grado, materias);

    mosquitto_lib_init();

    mosq = mosquitto_new("productor", true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error al crear el cliente Mosquitto\n");
        return 1;
    }

    ret = mosquitto_connect(mosq, "localhost", 1883, 60);
    if (ret != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error al conectar con el broker: %s\n", mosquitto_strerror(ret));
        mosquitto_destroy(mosq);
        mosquitto_lib_cleanup();
        return 1;
    }

    // Publicar el mensaje
    ret = mosquitto_publish(mosq, NULL, "test/topic", strlen(mensaje), mensaje, 0, false);
    if (ret == MOSQ_ERR_SUCCESS) {
        printf("Mensaje publicado: %s\n", mensaje);
    } else {
        fprintf(stderr, "Error al publicar el mensaje: %s\n", mosquitto_strerror(ret));
    }

    mosquitto_disconnect(mosq);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}
