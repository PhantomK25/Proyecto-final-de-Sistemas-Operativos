#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>
#include <mysql.h>

void on_message(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *msg) {
    if (msg->payloadlen) {
        printf("Mensaje recibido en el tópico '%s': %s\n", msg->topic, (char *)msg->payload);

        // Variables para almacenar los datos
        char nombre[50], primer_apellido[50], segundo_apellido[50], materias[100];
        int edad, matricula, grado;

        // Parsear el mensaje recibido
        int ret = sscanf((char *)msg->payload,
                         "Nuevo estudiante, Nombre: %49[^,], Primer Apellido: %49[^,], Segundo Apellido: %49[^,], Edad: %d, Matrícula: %d, Grado: %d, Materias: %99[^\n]",
                         nombre, primer_apellido, segundo_apellido, &edad, &matricula, &grado, materias);

        if (ret == 7) {
            printf("Datos parseados correctamente:\n");
            printf("Nombre: %s, Primer Apellido: %s, Segundo Apellido: %s, Edad: %d, Matrícula: %d, Grado: %d, Materias: %s\n",
                   nombre, primer_apellido, segundo_apellido, edad, matricula, grado, materias);

            // Conexión a la base de datos
            MYSQL *conn;
            conn = mysql_init(NULL);
            if (!conn) {
                fprintf(stderr, "mysql_init() falló\n");
                return;
            }

            if (!mysql_real_connect(conn, "localhost", "root", "root", "sistema_educativo", 0, NULL, 0)) {
                fprintf(stderr, "Error al conectar con la base de datos: %s\n", mysql_error(conn));
                mysql_close(conn);
                return;
            }

            // Insertar los datos en la base de datos
            char query[512];
            snprintf(query, sizeof(query),
                     "INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, edad, matricula, grado, materias) VALUES ('%s', '%s', '%s', %d, %d, %d, '%s')",
                     nombre, primer_apellido, segundo_apellido, edad, matricula, grado, materias);

            if (mysql_query(conn, query)) {
                fprintf(stderr, "Error al insertar datos: %s\n", mysql_error(conn));
            } else {
                printf("Datos insertados correctamente en la base de datos.\n");
            }

            mysql_close(conn);
        } else {
            fprintf(stderr, "Error al parsear el mensaje recibido.\n");
        }
    } else {
        printf("Mensaje recibido en el tópico '%s' (sin contenido).\n", msg->topic);
    }
}

int main() {
    struct mosquitto *mosq;

    mosquitto_lib_init();

    mosq = mosquitto_new("consumidor", true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error al crear el cliente Mosquitto\n");
        return 1;
    }

    mosquitto_message_callback_set(mosq, on_message);

    if (mosquitto_connect(mosq, "localhost", 1883, 60)) {
        fprintf(stderr, "No se pudo conectar al broker.\n");
        return 1;
    }

    mosquitto_subscribe(mosq, NULL, "test/topic", 0);

    printf("Esperando mensajes en el tópico 'test/topic'...\n");
    mosquitto_loop_forever(mosq, -1, 1);

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}
